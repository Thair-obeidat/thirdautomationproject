import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class MytestCases {

	WebDriver driver = new ChromeDriver();

	@BeforeTest
	public void mySetup() {
		driver.get("https://www.saucedemo.com/");
		driver.manage().window().maximize();

	}

	@Test(priority = 1)
	public void login() {
		String username = "standard_user";
		String password = "secret_sauce";

		WebElement UserNameInput = driver.findElement(By.id("user-name"));
		WebElement PasswordInput = driver.findElement(By.id("password"));
		WebElement LoginButton = driver.findElement(By.id("login-button"));

		UserNameInput.sendKeys(username);
		PasswordInput.sendKeys(password);
		LoginButton.click();
	}

	@Test(priority = 2)
	public void addtoCartAllitem() {
		List<WebElement> AddToCartButtons = driver.findElements(By.className("btn"));
		for (int i = 0; i < AddToCartButtons.size(); i++) {
			if(i==4) {
				break;
			}
			else {
				AddToCartButtons.get(i).click();

			}
		}
	}
}
